<?php

interface IIcms
{
    function BaseIcms();

    function ValorIcms();

    function BaseIcmsST();

    function ValorIcmsST();
}